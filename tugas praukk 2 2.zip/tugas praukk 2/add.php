<?php session_start(); ?>

<?php
if (!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>

<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
	</style>
	<title>Add Data</title>
</head>

<body>

	<?php
	include_once("connection.php");

	if (isset($_POST['Submit'])) {
		$name = $_POST['name'];
		$category = $_POST['category'];
		$country = $_POST['country'];
		$price = $_POST['price'];
		$loginId = $_SESSION['id'];

		if (empty($name) || empty($category) || empty($country) || empty($price)) {

			if (empty($name)) {
				echo "<font color='red'>Name field is empty.</font><br/>";
			}

			if (empty($category)) {
				echo "<font color='red'>Category field is empty.</font><br/>";
			}

			if (empty($country)) {
				echo "<font color='red'>Country field is empty.</font><br/>";
			}
			if (empty($price)) {
				echo "<font color='red'>Price field is empty.</font><br/>";
			}

			echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
		} else {
	
			$result = mysqli_query($mysqli, "INSERT INTO food(name, category, country , price, login_id) VALUES ('$name', '$category', '$country', '$price', '$loginId')");

			echo "<font color='green'>Data added successfully.";
			echo "<br/><a href='view.php'>View Result</a>";
		}
	}
	?>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
		crossorigin="anonymous"></script>

</body>

</html>