create database `foodstore`;

use `foodstore`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL primary key,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
);

CREATE TABLE `food` (
  `id` int(11) NOT NULL primary key,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL
);
